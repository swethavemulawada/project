package com.ofr.dao;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ofr.model.User;

/**
 * This interface is to get the inbuilt CRUD operations for User
 * 
 * @ JpaRepository <User,Integer>
 * 
 **/

@Repository
public interface UserDao extends JpaRepository<User, Integer>{

	@Query("select user from User user where user.userName=?1 and user.password=?2")
	public User validateUser(String userName, String password);
	
	User findByUserName(String username);
}
