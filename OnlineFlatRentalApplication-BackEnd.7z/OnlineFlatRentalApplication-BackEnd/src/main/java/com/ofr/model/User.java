package com.ofr.model;

/*
*	Entity Class
*
*	@Author : Sathya Sivam R
*/

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name = "UserTable")
public class User {

	@Id
	@GeneratedValue
	@Column(length = 15)
	private Integer userId;
	@Column(length = 15)
//	@NotNull
//	@Size(min = 1, max = 10, message = "User Name should have Minimum 5 and Maximum 10 Characters")
	private String userName;
	@Column(length=15)
	private String firstName;
	@Column(length=15)
	private String lastName;
	@Column(length=15)
	private String email;
	@Column(length=15)
	private String contactNo;
	@Column(length=15)
	private String address;
	@Column(length = 15)
//	@Size(min = 5, max = 8, message = "Enter the Valid Type")
	private String userType;
	@Column(length = 15)
//	@NotNull
//	@Pattern(regexp = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z])(?=.*[@#$&*]).{8,15}$", message = "Password must cointain capital, small letters and numbers and contain atleast One Special Character")
	private String password;
	
	/*
	 * Default Constructor
	 */
	public User() {
		
	}
	
	/*
	 * Parameterized Constructor
	 */
	public User(/*Integer userId,*/ String userName, String firstName, String lastName, String email, String contactNo,
			String address, String userType, String password) {
		super();
//		this.userId = userId;
		this.userName = userName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.contactNo = contactNo;
		this.address = address;
		this.userType = userType;
		this.password = password;
	}
	
	/*
	 * Getters and Setters for all private variables
	 */
	public Integer getUserId() {
		return userId;
	}
	
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getContactNo() {
		return contactNo;
	}
	
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	public String getUserType() {
		return userType;
	}
	
	public void setUserType(String userType) {
		this.userType = userType;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	/*
	 * To Sring Method to print the details
	 */
	@Override
	public String toString() {
		return "User [userId=" + userId + ",userName=" + userName + ", firstName=" + firstName + ", lastName="
				+ lastName + ", email=" + email + ", contactNo=" + contactNo + ", address=" + address + ", userType="
				+ userType + ", password=" + password + "]";
	}
	
	
}
