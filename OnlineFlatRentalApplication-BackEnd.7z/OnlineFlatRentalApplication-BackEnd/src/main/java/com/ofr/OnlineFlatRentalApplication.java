package com.ofr;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;



@SpringBootApplication
//@EnableSwagger2
public class OnlineFlatRentalApplication {
	
	
	@Bean
	public WebMvcConfigurer crosConfigurer()
	{
		return new WebMvcConfigurer() {
			
			
			public void addCrosMappings(CorsRegistry registry)
			{
				registry.addMapping("/*").allowedHeaders("*").allowedOrigins("*").allowedMethods("*").allowCredentials(true);
			}
			
		};
	}

	public static void main(String[] args) {
		SpringApplication.run(OnlineFlatRentalApplication.class, args);
		
	}
/*@Bean
	public Docket productApi() {
	return new Docket(DocumentationType.SWAGGER_2).select()
	.apis(RequestHandlerSelectors.basePackage("com.ofr")).build();
	}*/
}