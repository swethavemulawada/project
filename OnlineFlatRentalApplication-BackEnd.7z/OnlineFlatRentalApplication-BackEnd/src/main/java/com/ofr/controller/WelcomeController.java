package com.ofr.controller;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ofr.dto.AuthRequest;
import com.ofr.dto.UserDto;
import com.ofr.model.User;
import com.ofr.util.JwtUtil;
import com.ofr.dao.UserDao;

@RestController
@CrossOrigin( "http://localhost:4200/")
public class WelcomeController {
   @Autowired
	private JwtUtil util;
   @Autowired
   private AuthenticationManager authenticationManager;
   @Autowired
   private UserDao repos;
	@GetMapping("/")
	public String welcome()
	{
		return "welcome to capgemini";
	}
	@GetMapping("/find/by/{userName}")
	public User getRole(@PathVariable String userName)
	{
		return repos.findByUserName(userName);
	}
	
	@PostMapping("/authenticate")
	public String generateToken(@RequestBody AuthRequest authRequest) throws Exception
	{
		System.out.println(authRequest.getUserName() + " "+authRequest.getPassword());
		try
		{
	 authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUserName().trim(),authRequest.getPassword().trim()));
		}catch(Exception ex)
		{
			throw new Exception("Invalid user name and password");
		}
		return util.generateToken(authRequest.getUserName());
	}
}
