//package com.cg.ofr;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class FlatBookingClientTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
